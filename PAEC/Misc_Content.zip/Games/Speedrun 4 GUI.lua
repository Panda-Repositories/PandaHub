--Project Jojo--
if game.GameId == 798672140 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/ProjectJojo.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Lucky Battlegrounds--
if game.GameId == 279565647 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/LuckyBlockBattlegrounds.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Arsenal--
if game.GameId == 111958650 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/Arsenal.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Murder Mystery 2--
if game.GameId == 66654135 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/MurderMystery2.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Tower Of Hell--
if game.GameId == 703124385 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/TowerOfHell.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--A Bizarre Day--
if game.GameId == 969567031 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/ABizarreDay.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Speedrun 4--
if game.GameId == 83858907 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/SpeedRun4.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Horrific Housing--
if game.GameId == 107172930 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/HorifficHousing.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--No Scope Sniping: Remake (Extremely buggy, work in progress)--
if game.GameId == 1760106570 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/NoScopeSnipingRM.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Treacherous Tower--
if game.GameId == 1383164929 then 
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/TreacherousTower.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Prison Life-- 
if game.GameId == 73885730 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/PrisonLoof.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Soldier Sim--
if game.GameId == 1686423156 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/SoldierSimulator.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Area02--
if game.GameId == 1016500589 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/Area02.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Marble Mania--
if game.GameId == 1699709637 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/MarbleMania.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
--Unit: Classified--
if game.GameId == 1392301017 then
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/Unit.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end
-- Mayday -- 
if game.GameId == 1419144155 then 
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/Mayday.lua", true))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Um0e/Moon-Hub/master/jsonrequest.lua", true))()
end  