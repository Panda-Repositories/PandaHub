for i , v in pairs (workspace:GetDescendants()) do
    if v:IsA("Part") then
      if string.find(v.Name, "Flower") then
          if v.Transparency == 0 then
            local BillboardGui = Instance.new("BillboardGui")
    		local TextLabel = Instance.new("TextLabel")
    		BillboardGui.Parent = v
    		BillboardGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    		BillboardGui.Active = true
    		BillboardGui.AlwaysOnTop = true
    		BillboardGui.LightInfluence = 1
    		BillboardGui.Size = UDim2.new(0, 100, 0, 25)
    		TextLabel.Parent = BillboardGui
    		TextLabel.BackgroundColor3 = Color3.new(1, 1, 1)
    		TextLabel.BackgroundTransparency = 1
    		TextLabel.BorderSizePixel = 0
    		TextLabel.Size = UDim2.new(0, 100, 0, 25)
    		TextLabel.Font = Enum.Font.SourceSans
    		TextLabel.Text = v.Name
    		TextLabel.TextColor3 = v.Color
    		TextLabel.TextScaled = true
    		TextLabel.TextSize = 14
    		TextLabel.TextWrapped = true
    		if v.Name == "Flower1" then 
    			TextLabel.Text = "Blue Flower"
    		end
    		if v.Name == "Flower2" then
    		        TextLabel.Text = "Red Flower"
    		end
          end
      end
    end
end