-- TEXTING SIMULATOR AUTOFARM --
-- BY INNDOEZ --

local Click = game:GetService(â€œReplicatedStorageâ€).Events.SendTexts

local Settings = {
CPS = 0.45 -- Insert CPS here
}

local CPS = Settings.CPS

while true do
wait(CPS)
Click:FireServer()
end