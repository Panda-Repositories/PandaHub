_G.farm = true 
while _G.farm do
wait(0,1)
local A_1 = "Points"
local Event = game:GetService("ReplicatedStorage").RemoteEvent
Event:FireServer(A_1)
end