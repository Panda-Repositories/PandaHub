local A_1 = "Communication" --["O2" , "Energy"]
local Event = game:GetService("ReplicatedStorage").Events.Sabotage
Event:FireServer(A_1)