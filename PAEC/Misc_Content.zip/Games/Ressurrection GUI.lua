loadstring(game:HttpGet('http://impulse-hub.xyz/ImpulseHub',true))()

--[[
1. Press CTRL+A
2. Press CRTL+C
3. Go to your executor and click the script area
4. Press CTRL+V
5. Click execute

6. Go to https://discord.gg/uBkNUHk (optional)
]]--