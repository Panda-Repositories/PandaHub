local FleeTheFacilityGUI = Instance.new("ScreenGui")
local MainFrame = Instance.new("Frame")
local PlayersToggleButton = Instance.new("TextButton")
local ComputersToggleButton = Instance.new("TextButton")
local PodsToggleButton = Instance.new("TextButton")
local ExitDoorsToggleButton = Instance.new("TextButton")
local DoorsToggleButton = Instance.new("TextButton")
local AirVentsToggleButton = Instance.new("TextButton")
local ReloadESP = Instance.new("TextButton")
local HackingFailToggle = Instance.new("TextButton")

FleeTheFacilityGUI.Name = "FleeTheFacilityGUI"
FleeTheFacilityGUI.Parent = game.CoreGui

MainFrame.Name = "MainFrame"
MainFrame.Parent = FleeTheFacilityGUI
MainFrame.BackgroundColor3 = Color3.new(0, 0, 0)
MainFrame.BackgroundTransparency = 0.60000002384186
MainFrame.BorderSizePixel = 0
MainFrame.Position = UDim2.new(0.800000012, 0, 0.75, 0)
MainFrame.Size = UDim2.new(0.200000003, 0, 0.25, 0)

PlayersToggleButton.Name = "PlayersToggleButton"
PlayersToggleButton.Parent = MainFrame
PlayersToggleButton.BackgroundColor3 = Color3.new(0, 0, 0)
PlayersToggleButton.BorderColor3 = Color3.new(1, 1, 1)
PlayersToggleButton.BorderSizePixel = 2
PlayersToggleButton.Position = UDim2.new(0.0500000007, 0, 0.0500000007, 0)
PlayersToggleButton.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
PlayersToggleButton.Font = Enum.Font.SourceSansBold
PlayersToggleButton.FontSize = Enum.FontSize.Size24
PlayersToggleButton.Text = "Players: OFF"
PlayersToggleButton.TextColor3 = Color3.new(1, 0, 0)
PlayersToggleButton.TextScaled = true
PlayersToggleButton.TextSize = 24
PlayersToggleButton.TextWrapped = true

ComputersToggleButton.Name = "ComputersToggleButton"
ComputersToggleButton.Parent = MainFrame
ComputersToggleButton.BackgroundColor3 = Color3.new(0, 0, 0)
ComputersToggleButton.BorderColor3 = Color3.new(1, 1, 1)
ComputersToggleButton.BorderSizePixel = 2
ComputersToggleButton.Position = UDim2.new(0.0500000007, 0, 0.150000006, 0)
ComputersToggleButton.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
ComputersToggleButton.Font = Enum.Font.SourceSansBold
ComputersToggleButton.FontSize = Enum.FontSize.Size24
ComputersToggleButton.Text = "Computers: OFF"
ComputersToggleButton.TextColor3 = Color3.new(1, 0, 0)
ComputersToggleButton.TextScaled = true
ComputersToggleButton.TextSize = 24
ComputersToggleButton.TextWrapped = true

PodsToggleButton.Name = "PodsToggleButton"
PodsToggleButton.Parent = MainFrame
PodsToggleButton.BackgroundColor3 = Color3.new(0, 0, 0)
PodsToggleButton.BorderColor3 = Color3.new(1, 1, 1)
PodsToggleButton.BorderSizePixel = 2
PodsToggleButton.Position = UDim2.new(0.0500000007, 0, 0.25, 0)
PodsToggleButton.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
PodsToggleButton.Font = Enum.Font.SourceSansBold
PodsToggleButton.FontSize = Enum.FontSize.Size24
PodsToggleButton.Text = "Freeze Pods: OFF"
PodsToggleButton.TextColor3 = Color3.new(1, 0, 0)
PodsToggleButton.TextScaled = true
PodsToggleButton.TextSize = 24
PodsToggleButton.TextWrapped = true

ExitDoorsToggleButton.Name = "ExitDoorsToggleButton"
ExitDoorsToggleButton.Parent = MainFrame
ExitDoorsToggleButton.BackgroundColor3 = Color3.new(0, 0, 0)
ExitDoorsToggleButton.BorderColor3 = Color3.new(1, 1, 1)
ExitDoorsToggleButton.BorderSizePixel = 2
ExitDoorsToggleButton.Position = UDim2.new(0.0500000007, 0, 0.349999994, 0)
ExitDoorsToggleButton.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
ExitDoorsToggleButton.Font = Enum.Font.SourceSansBold
ExitDoorsToggleButton.FontSize = Enum.FontSize.Size24
ExitDoorsToggleButton.Text = "Exit Doors: OFF"
ExitDoorsToggleButton.TextColor3 = Color3.new(1, 0, 0)
ExitDoorsToggleButton.TextScaled = true
ExitDoorsToggleButton.TextSize = 24
ExitDoorsToggleButton.TextWrapped = true

DoorsToggleButton.Name = "DoorsToggleButton"
DoorsToggleButton.Parent = MainFrame
DoorsToggleButton.BackgroundColor3 = Color3.new(0, 0, 0)
DoorsToggleButton.BorderColor3 = Color3.new(1, 1, 1)
DoorsToggleButton.BorderSizePixel = 2
DoorsToggleButton.Position = UDim2.new(0.0500000007, 0, 0.449999988, 0)
DoorsToggleButton.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
DoorsToggleButton.Font = Enum.Font.SourceSansBold
DoorsToggleButton.FontSize = Enum.FontSize.Size24
DoorsToggleButton.Text = "Doors: OFF"
DoorsToggleButton.TextColor3 = Color3.new(1, 0, 0)
DoorsToggleButton.TextScaled = true
DoorsToggleButton.TextSize = 24
DoorsToggleButton.TextWrapped = true

AirVentsToggleButton.Name = "AirVentsToggleButton"
AirVentsToggleButton.Parent = MainFrame
AirVentsToggleButton.BackgroundColor3 = Color3.new(0, 0, 0)
AirVentsToggleButton.BorderColor3 = Color3.new(1, 1, 1)
AirVentsToggleButton.BorderSizePixel = 2
AirVentsToggleButton.Position = UDim2.new(0.0500000007, 0, 0.550000012, 0)
AirVentsToggleButton.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
AirVentsToggleButton.Font = Enum.Font.SourceSansBold
AirVentsToggleButton.FontSize = Enum.FontSize.Size24
AirVentsToggleButton.Text = "Air Vents: OFF"
AirVentsToggleButton.TextColor3 = Color3.new(1, 0, 0)
AirVentsToggleButton.TextScaled = true
AirVentsToggleButton.TextSize = 24
AirVentsToggleButton.TextWrapped = true

ReloadESP.Name = "ReloadESP"
ReloadESP.Parent = MainFrame
ReloadESP.BackgroundColor3 = Color3.new(0, 0, 0)
ReloadESP.BorderColor3 = Color3.new(1, 1, 1)
ReloadESP.BorderSizePixel = 2
ReloadESP.Position = UDim2.new(0.0500000007, 0, 0.699999988, 0)
ReloadESP.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
ReloadESP.Font = Enum.Font.SourceSansBold
ReloadESP.FontSize = Enum.FontSize.Size36
ReloadESP.Text = "ESP"
ReloadESP.TextColor3 = Color3.new(0, 0.447059, 0.454902)
ReloadESP.TextScaled = true
ReloadESP.TextSize = 34
ReloadESP.TextWrapped = true

HackingFailToggle.Name = "HackingFailToggle"
HackingFailToggle.Parent = MainFrame
HackingFailToggle.BackgroundColor3 = Color3.new(0, 0, 0)
HackingFailToggle.BorderColor3 = Color3.new(1, 1, 1)
HackingFailToggle.BorderSizePixel = 2
HackingFailToggle.Position = UDim2.new(0.0500000007, 0, 0.850000024, 0)
HackingFailToggle.Size = UDim2.new(0.899999976, 0, 0.0799999982, 0)
HackingFailToggle.Font = Enum.Font.SourceSansBold
HackingFailToggle.FontSize = Enum.FontSize.Size24
HackingFailToggle.Text = "Never fail hacking: OFF"
HackingFailToggle.TextColor3 = Color3.new(1, 0, 0)
HackingFailToggle.TextScaled = true
HackingFailToggle.TextSize = 24
HackingFailToggle.TextWrapped = true

players = false
computers = false
pods = false
exitdoors = false
doors = false
vents = false

neverfailhack = false

--------------------------------------------------
PlayersToggleButton.MouseButton1Down:connect(function()
if players == false then
players = true
PlayersToggleButton.Text = "Players: ON"
PlayersToggleButton.TextColor3 = Color3.fromRGB(0,255,0)
else
players = false
PlayersToggleButton.Text = "Players: OFF"
PlayersToggleButton.TextColor3 = Color3.fromRGB(255,0,0)
end
end)

ComputersToggleButton.MouseButton1Down:connect(function()
if computers == false then
computers = true
ComputersToggleButton.Text = "Computers: ON"
ComputersToggleButton.TextColor3 = Color3.fromRGB(0,255,0)
else
computers = false
ComputersToggleButton.Text = "Computers: OFF"
ComputersToggleButton.TextColor3 = Color3.fromRGB(255,0,0)
end
end)

PodsToggleButton.MouseButton1Down:connect(function()
if pods == false then
pods = true
PodsToggleButton.Text = "Freeze Pods: ON"
PodsToggleButton.TextColor3 = Color3.fromRGB(0,255,0)
else
pods = false
PodsToggleButton.Text = "Freeze Pods: OFF"
PodsToggleButton.TextColor3 = Color3.fromRGB(255,0,0)
end
end)

ExitDoorsToggleButton.MouseButton1Down:connect(function()
if exitdoors == false then
exitdoors = true
ExitDoorsToggleButton.Text = "Exit Doors: ON"
ExitDoorsToggleButton.TextColor3 = Color3.fromRGB(0,255,0)
else
exitdoors = false
ExitDoorsToggleButton.Text = "Exit Doors: OFF"
ExitDoorsToggleButton.TextColor3 = Color3.fromRGB(255,0,0)
end
end)

DoorsToggleButton.MouseButton1Down:connect(function()
if doors == false then
doors = true
DoorsToggleButton.Text = "Doors: ON"
DoorsToggleButton.TextColor3 = Color3.fromRGB(0,255,0)
else
doors = false
DoorsToggleButton.Text = "Doors: OFF"
DoorsToggleButton.TextColor3 = Color3.fromRGB(255,0,0)
end
end)

AirVentsToggleButton.MouseButton1Down:connect(function()
if vents == false then
vents = true
AirVentsToggleButton.Text = "Air Vents: ON"
AirVentsToggleButton.TextColor3 = Color3.fromRGB(0,255,0)
else
vents = false
AirVentsToggleButton.Text = "Air Vents: OFF"
AirVentsToggleButton.TextColor3 = Color3.fromRGB(255,0,0)
end
end)

HackingFailToggle.MouseButton1Down:connect(function()
if neverfailhack == false then
neverfailhack = true
HackingFailToggle.Text = "Never fail hacking: ON"
HackingFailToggle.TextColor3 = Color3.fromRGB(0,255,0)
else
neverfailhack = false
HackingFailToggle.Text = "Never fail hacking: OFF"
HackingFailToggle.TextColor3 = Color3.fromRGB(255,0,0)
end
end)

ReloadESP.MouseButton1Down:connect(function()
game.Lighting.FogEnd = 10000000

if workspace:findFirstChild("ESP") then
workspace.ESP:remove()
end

if workspace:findFirstChild("ESPComputer") then
workspace.ESPComputer:remove()
end

if workspace:findFirstChild("ESPPod") then
workspace.ESPPod:remove()
end

if workspace:findFirstChild("ESPExitDoor") then
workspace.ESPExitDoor:remove()
end

if workspace:findFirstChild("ESPDoors") then
workspace.ESPDoors:remove()
end

if workspace:findFirstChild("ESPVents") then
workspace.ESPVents:remove()
end


function GetSizeOfObject(Obj)
if Obj:IsA("BasePart") then
return Obj.Size
elseif Obj:IsA("Model") then
return Obj:GetExtentsSize()
end
end

local ESP = Instance.new("Folder",workspace)
ESP.Name = "ESP"



function CreateESPPart(BodyPart,r,g,b)
local ESPPartparent = BodyPart
local Box = Instance.new("BoxHandleAdornment")
Box.Size = GetSizeOfObject(ESPPartparent) + Vector3.new(0.1, 0.1, 0.1)
Box.Name = "ESPPart"
Box.Adornee = ESPPartparent
Box.Color3 = Color3.fromRGB(r,g,b)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.4
Box.Parent = ESP
if BodyPart.Parent.Name == game.Players.LocalPlayer.Name then
Box:remove()
spawn (function()
while true do
wait(0.1)
if BodyPart ~= nil then
Box:remove()
end
end
end)
end
end


local player = game.Players:GetChildren()
for i =1, #player do
local bodyparts = player[i].Character:GetChildren()
for i =1, #bodyparts do
if bodyparts[i].ClassName == "Part" then
if bodyparts[i].Parent:findFirstChild("BeastPowers") then
CreateESPPart(bodyparts[i],255,0,0)
else
CreateESPPart(bodyparts[i],170,170,255)
end
end
end
end


local ESPPC = Instance.new("Folder",workspace)
ESPPC.Name = "ESPComputer"

local ESPPod = Instance.new("Folder",workspace)
ESPPod.Name = "ESPPod"

local ESPExitDoor = Instance.new("Folder",workspace)
ESPExitDoor.Name = "ESPExitDoor"

local ESPDoors = Instance.new("Folder",workspace)
ESPDoors.Name = "ESPDoors"

local ESPVents = Instance.new("Folder",workspace)
ESPVents.Name = "ESPVents"


local map = workspace:findFirstChild(tostring(game.ReplicatedStorage.CurrentMap.Value))
local children = map:GetChildren()
for i =1, #children do
if children[i].Name == "ComputerTable" then
local Box = Instance.new("BoxHandleAdornment")
Box.Size = GetSizeOfObject(children[i].Screen) + Vector3.new(-0.5, -0.5, -0.5)
Box.Name = "ESPPart"
Box.Adornee = children[i].Screen
spawn (function()
while true do
wait(0.1)
Box.Color3 = children[i].Screen.Color
end
end)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.4
Box.Parent = ESPPC
end
if children[i].Name == "FreezePod" then
local Box = Instance.new("BoxHandleAdornment")
Box.Size = GetSizeOfObject(children[i].BasePart) + Vector3.new(0.1, 5, 0.1)
Box.Name = "ESPPart"
Box.Adornee = children[i].BasePart
Box.Color3 = Color3.fromRGB(0,0,255)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPPod
end
if children[i].Name == "ExitDoor" then
local Box = Instance.new("BoxHandleAdornment")
Box.Size = GetSizeOfObject(children[i].ExitDoorTrigger) + Vector3.new(-1, 5, -1)
Box.Name = "ESPPart"
Box.Adornee = children[i].ExitDoorTrigger
Box.Color3 = Color3.fromRGB(255,255,0)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPExitDoor
end
if children[i].Name == "SingleDoor" then
local Box = Instance.new("BoxHandleAdornment")
if children[i].Door:findFirstChild("DoorBoard") then
Box.Size = GetSizeOfObject(children[i].Door.DoorBoard) + Vector3.new(0.1, 0.1, 0.1)
Box.Name = "ESPPart"
Box.Adornee = children[i].Door.DoorBoard
Box.Color3 = Color3.fromRGB(204,142,105)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPDoors
end
end
if children[i].Name == "DoubleDoor" then
local Box = Instance.new("BoxHandleAdornment")
if children[i].DoorL:findFirstChild("DoorBoard") then
Box.Size = GetSizeOfObject(children[i].DoorL.DoorBoard) + Vector3.new(0.1, 0.1, 0.1)
Box.Name = "ESPPart"
Box.Adornee = children[i].DoorL.DoorBoard
Box.Color3 = Color3.fromRGB(204,142,105)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPDoors
end
end
if children[i].Name == "DoubleDoor" then
local Box = Instance.new("BoxHandleAdornment")
if children[i].DoorR:findFirstChild("DoorBoard") then
Box.Size = GetSizeOfObject(children[i].DoorR.DoorBoard) + Vector3.new(0.1, 0.1, 0.1)
Box.Name = "ESPPart"
Box.Adornee = children[i].DoorR.DoorBoard
Box.Color3 = Color3.fromRGB(204,142,105)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPDoors
end
end
if children[i].Name == "SingleDoor" then
local Box = Instance.new("BoxHandleAdornment")
if children[i].Door:findFirstChild("DoorBoard") == false then
Box.Size = GetSizeOfObject(children[i].Door.Part) + Vector3.new(0.1, 0.1, 0.1)
Box.Name = "ESPPart"
Box.Adornee = children[i].Door.Part
Box.Color3 = Color3.fromRGB(204,142,105)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPDoors
end
end
if children[i].Name == "DoubleDoor" then
local Box = Instance.new("BoxHandleAdornment")
if children[i].DoorR:findFirstChild("DoorBoard") == false then
Box.Size = GetSizeOfObject(children[i].DoorL.Part) + Vector3.new(0.1, 0.1, 0.1)
Box.Name = "ESPPart"
Box.Adornee = children[i].DoorL.Part
Box.Color3 = Color3.fromRGB(204,142,105)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPDoors
end
end
if children[i].Name == "DoubleDoor" then
local Box = Instance.new("BoxHandleAdornment")
if children[i].DoorR:findFirstChild("DoorBoard") == false then
Box.Size = GetSizeOfObject(children[i].DoorR.Part) + Vector3.new(0.1, 0.1, 0.1)
Box.Name = "ESPPart"
Box.Adornee = children[i].DoorR.Part
Box.Color3 = Color3.fromRGB(204,142,105)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPDoors
end
end

if children[i].Name == "AirVent" then
local Box = Instance.new("BoxHandleAdornment")
Box.Size = GetSizeOfObject(children[i].Part) + Vector3.new(4, 0.1, 4)
Box.Name = "ESPPart"
Box.Adornee = children[i].Part
Box.Color3 = Color3.fromRGB(100,100,100)
Box.AlwaysOnTop = true
Box.ZIndex = 5
Box.Transparency = 0.8
Box.Parent = ESPVents
end
end

if players == false then
workspace.ESP:remove()
end

if computers == false then
workspace.ESPComputer:remove()
end

if pods == false then
workspace.ESPPod:remove()
end

if exitdoors == false then
workspace.ESPExitDoor:remove()
end

if doors == false then
workspace.ESPDoors:remove()
end

if vents == false then
workspace.ESPVents:remove()
end
end)

spawn (function()
while true do
wait()
if neverfailhack == true then
game.ReplicatedStorage.RemoteEvent:FireServer("SetPlayerMinigameResult",true)
end
end
end)