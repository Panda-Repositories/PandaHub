local Armours = {"Scrap Armour",
"Gold Armour",
"Diamond Armour",
"Bluesteel Armour",
"Viridis Armour",
"Amberstone Armour",
"Rainbow Armour",
"Ultimate Armour",
"True Armour",
"Armour of Destiny",
"Shard Armour",
"Nacker's Armour",
"Omega Death Armour",
"Sky Armour",
"Enchanted Sky Armour",
"Dank Armour",
"Purple Vermite Armour",
"Green Vermite Armour",
"Royal Armour",
"Enchanted Royal Armour",
"Ruler's Armour",
"Enchanted Ruler's Armour",
"Epic Armour",
"Knight's Armour",
"Laser Armour",
"Black Vermite Armour",
"Basic Armour",
"Speedy Armour",
"Military Armour",
"Heavy Armour",
"Omega Death Armour"}

local Meteors = {
"Bane of Life",
"Black Vermite Scythe",
"Black Vermite Sword",
"Dank Scythe",
"Death's Scythe",
"Demonic Blade",
"Demonic Blade",
"Enchanted Royal Sword",
"Enchanted Ruler's Sword",
"Enchanted Sky Sword",
"Excalibur",
"Nacker's Scythe",
"Omega Death Scythe",
"Royal Sword",
"Ruler's Excalibur",
"Ruler's Sword",
"Sky Scythe",
"Sky Sword",
"Stazzler",
"Sword of Destiny",
"The Catalyst"
}

local Pickaxes = {
"Scrap Pickaxe",
"Gold Pickaxe",
"Diamond Pickaxe",
"Bluesteel Pickaxe",
"Viridis Pickaxe",
"Vermite Pickaxe",
"Pickaxe of Light",
"Pickaxe of Doom",
"Royal Pickaxe"
}

local Shields = {
"Sword of Evil",
"Titan Shield",
"Metal Shield",
"Sea's Revenge"
}

function GetPlayers()
  local PlayerTable = {}

  for _, Player in next, game.Players:GetPlayers() do
    table.insert(PlayerTable, Player.Name)
  end

  return PlayerTable
end

local Material = loadstring(game:HttpGet("https://raw.githubusercontent.com/Kinlei/MaterialLua/master/Module.lua"))()

local X = Material.Load({
	Title = "sleep#8303 craftwar's fucker",
	Style = 1,
	SizeX = 500,
	SizeY = 350,
	Theme = "Dark",
	ColorOverrides = {
		MainFrame = Color3.fromRGB(40,40,40)
	}
})

local LocalPlayer = X.New({
	Title = "Main"
})

local GodMode = LocalPlayer.Button({
	Text = "God Mode",
	Callback = function()
        for i, v in next, Armours do
            local armour = game:GetService("Players").LocalPlayer.Character:FindFirstChild(v);
            if (armour) then
                local args = {
                    [1] = "protect",
                    [2] = {
                        [1] = game:GetService("Players").LocalPlayer.Character,
                        [2] = game:GetService("Players").LocalPlayer.Character.Humanoid,
                        [3] = math.huge
                    }
                }
                armour.RemoteFunction:InvokeServer(unpack(args))
            end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Equips armour to all players so they get god mode. Make sure to use this with armour in your hand."
			})
		end
	}
})

local GodAll = LocalPlayer.Button({
	Text = "God All",
	Callback = function()
        for i, v in next, Armours do
            local armour = game:GetService("Players").LocalPlayer.Character:FindFirstChild(v);
            if (armour) then
                for _, Player in next, game.Players:GetPlayers() do
                    local args = {
                        [1] = "protect",
                            [2] = {
                                [1] = Player.Character,
                                [2] = Player.Character.Humanoid,
                                [3] = math.huge
                            }
                        }
                    armour.RemoteFunction:InvokeServer(unpack(args))
                end
            end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Equips armour to all players so they get god mode. Make sure to use this with armour in your hand."
			})
		end
	}
})

local FF = LocalPlayer.Button({
	Text = "Forcefield",
	Callback = function()
        for i, v in next, Shields do
            local shield = game:GetService("Players").LocalPlayer.Character:FindFirstChild(v);
            if (shield) then
                while true do
                    wait(0.00000001)
                    local args = {
                        [1] = "shield",
                        [2] = game:GetService("Players").LocalPlayer.Character
                    }
                    
                    shield.RemoteFunction:InvokeServer(unpack(args))
                end
            end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Loops forcefield."
			})
		end
	}
})

local FFAll = LocalPlayer.Button({
	Text = "Forcefield All",
	Callback = function()
        for i, v in next, Shields do
            local shield = game:GetService("Players").LocalPlayer.Character:FindFirstChild(v);
            if (shield) then
                while true do
                    wait(0.00001)
                    for _, Player in next, game.Players:GetPlayers() do
                        local args = {
                            [1] = "shield",
                            [2] = Player.Character
                        }
                        
                        shield.RemoteFunction:InvokeServer(unpack(args))
                    end
                end
            end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Loops forcefield for all."
			})
		end
	}
})

local GetAllTools = LocalPlayer.Button({
    Text = "Get All Tools",
	Callback = function()
		count=0
        for i=1,1000 do
        count=count+1
        game.Players.LocalPlayer.PlayerGui.Inventory.GuiControl:Invoke({command="insert", id = count})
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Get all ingame items."
			})
		end
	}
})

local Autofarm = LocalPlayer.Button({
	Text = "Autofarm/AutoKill",
	Callback = function()
        for i, v in next, Meteors do
            local meteor = game:GetService("Players").LocalPlayer.Character:FindFirstChild(v);
            if (meteor) then
                while true do
                    wait(0.00001)
                    for i,v in pairs(game.Workspace:GetChildren()) do
                    local headpos = v:FindFirstChild("Head")
                    if headpos then
                    local args = {
                        [1] = "meteor",
                        [2] = {
                            [1] = math.huge,
                            [2] = headpos
                        }
                    }
                    
                    meteor.RemoteFunction:InvokeServer(unpack(args))
                    end
                    end
                    end
            end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Autofarm kills using meteor type weapons like scythes."
			})
		end
	}
})

local KillAll = LocalPlayer.Button({
	Text = "Kill All",
	Callback = function()
        while true do
        wait(0.00001)
        for i,v in pairs(game.Workspace:GetChildren()) do
        local headpos = v:FindFirstChild("Head")
        if headpos then
        local args = {
            [1] = "hit",
            [2] = {
                [1] = headpos.Parent.Humanoid,
                [2] = math.huge
            }
        }
        local weapon = game:GetService("Players").LocalPlayer.Character:FindFirstChildOfClass("Tool")
        weapon.RemoteFunction:InvokeServer(unpack(args))
        end
        end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Kill all players using the weapon you equip."
			})
		end
	}
})

local AutoMine = LocalPlayer.Button({
	Text = "Automine",
	Callback = function()
        for i, v in next, Pickaxes do
            local Pickaxe = game:GetService("Players").LocalPlayer.Character:FindFirstChild(v);
            if (Pickaxe) then
                while true do
                    wait(0.00001)
                    for i,v in pairs(game.Workspace.Mine2:GetChildren()) do
                        if v:IsA("Model") then
                            local ore = v:FindFirstChild("Ore")
                            if ore then
                                local args = {
                                    [1] = "hit",
                                    [2] = {
                                        [1] = ore,
                                        [2] = math.huge
                                    }
                                }
                                game:GetService("Players").LocalPlayer.Character["Royal Pickaxe"].RemoteFunction:InvokeServer(unpack(args))
                            end
                        end
                    end
                    for i,v in pairs(game.Workspace.Mine:GetChildren()) do
                        if v:IsA("Model") then
                            local ore = v:FindFirstChild("Ore")
                            if ore then
                                local args = {
                                    [1] = "hit",
                                    [2] = {
                                        [1] = ore,
                                        [2] = math.huge
                                    }
                                }
                                game:GetService("Players").LocalPlayer.Character["Royal Pickaxe"].RemoteFunction:InvokeServer(unpack(args))
                            end
                        end
                    end
                end
            end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Auomine ores in the game. Requires Pickaxe."
			})
		end
	}
})
local lagserver = LocalPlayer.Button({
	Text = "Mass Explosion/Lag Server",
	Callback = function()
                while true do
                wait(0.00001)
                for i,v in pairs(game.Workspace:GetChildren()) do
                    local headpos = v:FindFirstChild("Head")
                    if headpos then
                        local args = {
                            [1] = "explosion",
                            [2] = {
                                [1] = headpos.Position,
                                [2] = math.huge
                            }
                        }
                        
                        game:GetService("Players").LocalPlayer.Character["Scroll of Sevenless"].RemoteFunction:InvokeServer(unpack(args))
                        end
                    end
        end
	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "Spam explosions with scrolls of sevenless."
			})
		end
	}
})

local NegInfCash = LocalPlayer.Button({
    Text = "Ngeative Infinite Cash (Read Information)",
	Callback = function()
        local args = {
            [1] = {
                ["command"] = "setvalue",
                ["value"] = -math.huge,
                ["instance"] = game:GetService("Players").LocalPlayer.realstats.Cash
            }
        }
        
        game:GetService("ReplicatedStorage").MainControl:InvokeServer(unpack(args))

	end,
	Menu = {
		Information = function(self)
			X.Banner({
				Text = "You get infinite negative cash '-inf'. Please don't use unless you don't want to buy anything in game. Any attempts to revert this will get you banned. If you try to use the remote to give you more money than you have, you get banned."
			})
		end
	}
})