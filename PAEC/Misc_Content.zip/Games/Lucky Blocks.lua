for i = 1,100 do 
game.ReplicatedStorage.SpawnGalaxyBlock:FireServer()
end
-- change the "galaxy block" to whatever block you want. (case sensitive)